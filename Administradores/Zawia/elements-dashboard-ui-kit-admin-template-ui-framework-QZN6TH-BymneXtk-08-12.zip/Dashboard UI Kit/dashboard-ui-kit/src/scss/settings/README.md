
## Naming Variables:


Variables should follow the `$component-state-property-size` formula for
consistent naming.


```
EXAMPLE: $btn-disabled-padding-small
```

## Variable Sizes

There is components like `avatar` which has different sizes, thoses sizes 
should be:

- xsmall
- small 
- medium
- large
- xlarge