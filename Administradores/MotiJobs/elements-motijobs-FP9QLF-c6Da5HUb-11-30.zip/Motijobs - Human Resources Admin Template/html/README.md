home √

job-search √
job preview √
job registartion full width √
job registration sidebar √

proffessionals √


candidate profile √
candidate registration √

registration step 1 √
registration step 2 √
registration step 3 √
registration step 4 √

out agents √
agent profile √
add agent √

our client √
qucik add client √
client profile √
client team √
applicants √
client registration
