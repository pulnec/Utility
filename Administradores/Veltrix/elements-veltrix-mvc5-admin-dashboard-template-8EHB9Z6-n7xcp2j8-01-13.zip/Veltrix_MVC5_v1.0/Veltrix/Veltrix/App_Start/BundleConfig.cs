﻿using System.Web;
using System.Web.Optimization;

namespace Veltrix
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {

        }
    }
}
